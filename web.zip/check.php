<?php
// Security headers & error reporting
header("Content-Type: text/plain");
header("X-Content-Type-Options: nosniff");
error_reporting(E_ALL);
// error_reporting(0); // Disable error display
ini_set('display_errors', 0);

// Database configuration (consider moving to environment variables)
const DB_HOST = 'localhost';
const DB_USER = 'super_roottt';
const DB_PASS = 'NBVutkcg012549^@!%$#!)@&@!';
const DB_NAME = 'crazysystem';

// Valid scripts (consider moving to database table with caching)
const VALID_SCRIPTS = [
    'Crazy_CallAdmin_Jail',
    'Crazy_PlayerInfo_V3',
    'Crazy_PlayerInfo_V4',
    'Crazy_PlayerConnect_V2',
    'Crazy_Server_Logs_V1',
    'Crazy_GiveWeapons',
    'Crazy_lscustoms',
    'Crazy_OfflineJail',
    'Crazy_Change_Id',
    'Crazy_Change_Id_V3',
    'Crazy_Change_Id_V3_1',
    'Crazy_VIP_Menu',
    'Crazy_ScreenShots',
    'Crazy_vRP_Files',
    'test_test',
    'Crazy_vRP_File_For_Drift'
];

try {
    // Validate input parameters
    $scriptId = $_GET['ID'] ?? '';
    $ipAddress = $_GET['IP'] ?? '';
    
    // Basic input validation
    if (empty($scriptId) || empty($ipAddress)) {
        throw new Exception('Missing parameters');
    }
    
    // Validate IP format
    if (!filter_var($ipAddress, FILTER_VALIDATE_IP)) {
        throw new Exception('Invalid IP format');
    }
    
    // Validate script ID format (alphanumeric and underscores)
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $scriptId)) {
        throw new Exception('Invalid script ID format');
    }
    
    // Check against valid scripts
    if (!in_array($scriptId, VALID_SCRIPTS, true)) {
        throw new Exception('Invalid script ID');
    }

    // Database connection
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        throw new Exception('Database connection failed');
    }
    
    // Set character set
    $conn->set_charset('utf8mb4');

    // Prepared statement
    $stmt = $conn->prepare("SELECT 1 FROM customers WHERE ID = ? AND IP = ? LIMIT 1");
    if (!$stmt) {
        throw new Exception('Database preparation failed');
    }
    
    $stmt->bind_param("ss", $scriptId, $ipAddress);
    $stmt->execute();
    $stmt->store_result();
    
    // Return result
    echo $stmt->num_rows > 0 ? "true" : "false";

    // Cleanup
    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    // Log errors (implement proper logging)
    // error_log('License Error: ' . $e->getMessage());
    echo "false";
    exit;
}