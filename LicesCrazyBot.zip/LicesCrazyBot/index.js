const { Client, GatewayIntentBits, Collection } = require("discord.js");
const fs = require("fs");
const config = require("./tools/config");
const { fetchLicenses, updateLicenses, stopLicenses, removeOwner, moveOwner, createLicense, checkLicenses, removeLicenseById } = require("./tools/db");

const bot = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

bot.commands = new Collection();
bot.aliases = new Collection();

const loadCommands = () => {
    const commandFiles = fs.readdirSync("./commands").filter(file => file.endsWith(".js"));
    if (commandFiles.length === 0) {
        console.log("No commands found.");
        return;
    }

    commandFiles.forEach(file => {
        try {
            const command = require(`./commands/${file}`);

            if (!command.help || !command.help.name) {
                console.error(`Command file ${file} is missing a valid 'help' object.`);
                return;
            }

            bot.commands.set(command.help.name, command);
            if (command.help.aliases && Array.isArray(command.help.aliases)) {
                command.help.aliases.forEach(alias => bot.aliases.set(alias, command.help.name));
            }
            console.log(`${file} loaded`);
        } catch (error) {
            console.error(`Error loading command file ${file}:`, error);
        }
    });
};

bot.on("ready", () => {
    console.log(`${bot.user.username} is online!`);
    bot.user.setActivity("لتغير الايبي اكتب | !بدل | !update");
});

bot.on("messageCreate", async (message) => {
    if (message.author.bot || !message.guild) return;

    const prefix = config.prefix;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const commandName = args.shift().toLowerCase();

    const command = bot.commands.get(commandName) || bot.commands.get(bot.aliases.get(commandName));
    if (!command) return;

    try {
        await command.run(bot, message, args, {
            fetchLicenses,
            updateLicenses,
            stopLicenses,
            removeOwner,
            moveOwner,
            createLicense,
            checkLicenses,
            removeLicenseById
        });
    } catch (error) {
        console.error("Error executing command:", error);
        message.reply("هناك خطأ أثناء تنفيذ الأمر!");
    }
});

loadCommands();
bot.login(config.botToken);
