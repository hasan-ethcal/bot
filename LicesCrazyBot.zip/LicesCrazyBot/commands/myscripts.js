const { fetchLicenses } = require('../tools/db'); // Reuse database functions
const logger = require('../tools/logger');

module.exports.run = async (bot, message, args) => {
    const ownerId = message.author.id;

    // Delete the command message
    message.delete();

    try {
        // Fetch the user's licenses
        const licenses = await fetchLicenses(ownerId);

        // Check if the user has any licenses
        if (licenses.length === 0) {
            return message.channel.send(`**[ لا تمتلك اي ترخيص في النظام اذا كنت شاري سكربت مني يرجى التواصل خاص شكرا لصبرك ]. <@355199972666376202> || <@${ownerId}>**`);
        }

        // Build the response message
        let msg = "**Your Licenses:**\n";
        licenses.forEach((element, index) => {
            msg += `**${index + 1}.** \`${element.ID}\` => \`${element.IP}\`\n`;
        });
        msg += `**That's All Love. || <@${ownerId}> ||**`;

        // Send the consolidated message
        await message.channel.send(msg);

        // Log the action
        // logger.info(`[SCRIPT CHECK]: ${ownerId} checked their licenses.`);
        console.log(`[SCRIPT CHECK] - [${new Date().toLocaleString()}]: ${ownerId} checked their licenses!.`);
    } catch (err) {
        logger.error("Error fetching licenses:", err);
        // console.error("Error fetching licenses:", err);
        message.channel.send("**An error occurred while fetching your licenses.**");
    }
};

module.exports.help = {
    name: "myscripts",
    aliases: ["my"]
};



