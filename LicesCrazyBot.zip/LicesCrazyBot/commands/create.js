const { createLicense } = require('../tools/db'); // Reuse database functions

module.exports.run = async (bot, message, args) => {
    // Add both admin IDs to this array
    const authorizedUserId = ["355199972666376202", "695664615534755850"]; // Replace with the authorized Discord ID

    // Check if the user is authorized
    if (!authorizedUserId.includes(message.author.id)) {
        message.delete();
        return message.channel.send("**You are not authorized to use this command.**");
    }

    // Check if all required arguments are provided
    if (args.length < 3) {
        message.delete();
        return message.channel.send("**Missing arguments. Usage: `!create <ID_Script> <IP_Address> <Owner>`**");
    }

    const resourceId = args[0].trim(); // Sanitize input
    const serverIp = args[1].trim(); // Sanitize input
    const ownerId = args[2].trim(); // Sanitize input

    // Delete the command message
    message.delete();

    try {
        // Insert data into the database
        const result = await createLicense(resourceId, serverIp, ownerId);

        // Send success message
        // await message.channel.send(`**[NEW LICENSE]**\n**Resource_Name:** (${resourceId})\n**|| Server_IP:** (${serverIp})\n**|| Resource_Owner:** <@${ownerId}>`);
        await message.channel.send(`**NEW LICENSE**\n**Resource_Name:** \`\` (${resourceId}) \`\`\n**Server_IP:** \`\` (${serverIp}) \`\`\n**Resource_Owner:** <@${ownerId}>`);
        console.log(`[NEW LICENSE] [${new Date().toLocaleString()}]: Resource_Name: (${resourceId}) || Server_IP: (${serverIp}) || Resource_Owner: (<@${ownerId}>) ||`);
        // console.log(`[NEW LICENSE]: [ ${resourceId} | ${serverIp} | ${ownerId} ]`);
    } catch (err) {
        console.error("Error creating license:", err);
        message.channel.send("**An error occurred while creating the license.**");
    }
};

module.exports.help = {
    name: "create",
    aliases: ["create"]
};