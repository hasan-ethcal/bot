const { fetchLicenses, updateLicenses } = require('../tools/db');
const isValidIp = require('../tools/ipValidator');
const rateLimit = require('../tools/rateLimiter');
const logger = require('../tools/logger');

module.exports.run = async (bot, message, args) => {
    const ownerId = message.author.id;

    // Rate limiting
    if (!rateLimit(ownerId)) {
        return message.channel.send("**لقد تجاوزت الحد المسموح من الطلبات. يرجى الانتظار قبل المحاولة مرة أخرى.**");
    }

    // Check if the IP argument is provided
    if (!args[0]) {
        message.delete();
        return message.channel.send("**خطا في التغير**\n**Example | مثال**\n```!بدل 127.0.0.1```\n```!update 127.0.0.1```\n\n<@" + message.author.id + ">");
    }

    const newIp = args[0].trim(); // Sanitize input

    // Validate IP address
    if (!isValidIp(newIp)) {
        return message.channel.send("**عنوان IP غير صالح.**");
    }

    // Delete the command message
    message.delete();

    try {
        // Fetch the user's licenses
        const licenses = await fetchLicenses(ownerId);

        // Check if the user has any licenses
        if (licenses.length === 0) {
            return message.channel.send("**لا تمتلك أي تراخيص لتحديثها.**");
        }

        // Update the IP for all licenses
        await updateLicenses(newIp, ownerId);

        // Build the response message
        let successMessage =  `**New IP =>** \`\` ${newIp} \`\` **<= تم تغيير جميع السكربتات التي تمتلكها إلى الايبي بنجاح.**\n\n`;
        licenses.forEach((element, index) => {
            successMessage += `**${index + 1}.** \`${element.ID}\` => \`${newIp}\`\n`;
            console.log(`[UPDATE] [${new Date().toLocaleString()}]: ${ownerId} changed the IP for ${element.ID} from ${element.IP} to ${newIp}`);
            // logger.info(`[UPDATE]: ${ownerId} changed the IP for ${element.ID} from ${element.IP} to ${newIp}`);
        });
        successMessage += `**That's All Love. || <@${ownerId}> ||**`;

        // Send the consolidated message
        await message.channel.send(successMessage);
        
    } catch (err) {
        //console.error("Error:", err);
        logger.error("Error updating licenses:", err);
        message.channel.send("**حدث خطأ أثناء معالجة طلبك.**");
    }
};

module.exports.help = {
    name: "update",
    aliases: ["بدل"]
};