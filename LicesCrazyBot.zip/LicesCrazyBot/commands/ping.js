module.exports.run = async (bot, message, args) => {
    try {
        // Send an initial message to measure latency
        const m = await message.channel.send("**Pinging...**");

        // Calculate the bot's latency (round-trip time)
        const botLatency = m.createdTimestamp - message.createdTimestamp;

        // Get the WebSocket ping (API latency)
        const apiLatency = Math.round(bot.ws.ping);

        // Edit the message with the latency information
        m.edit(`**Ping!**\n- **Bot Latency:** ${botLatency}ms\n- **API Latency:** ${apiLatency}ms`);
    } catch (error) {
        console.error("Error in ping command:", error);
        message.channel.send("**An error occurred while calculating the ping.**");
    }
};

module.exports.help = {
    name: "ping",
    aliases: ["p"]
};