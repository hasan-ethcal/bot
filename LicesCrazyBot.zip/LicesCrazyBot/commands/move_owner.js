const { moveOwner } = require('../tools/db'); // Reuse database functions

module.exports.run = async (bot, message, args) => {
    const authorizedUserId = "355199972666376202"; // Replace with a config value or environment variable

    // Check authorization
    if (message.author.id !== authorizedUserId) {
        message.delete();
        return message.channel.send("**You are not authorized to use this command.**");
    }

    // Check if arguments are provided
    if (args.length < 2) {
        message.delete();
        return message.channel.send("**Missing arguments. Usage: `!move <OldOwnerID> <NewOwnerID>`**");
    }

    const oldOwnerId = args[0].trim(); // Sanitize input
    const newOwnerId = args[1].trim(); // Sanitize input

    // Delete the command message
    message.delete();

    try {
        // Move ownership in the database
        const result = await moveOwner(oldOwnerId, newOwnerId);

        // Check if any rows were affected
        if (result.affectedRows === 0) {
            return message.channel.send(`**No licenses found for owner <@${oldOwnerId}>.**`);
        }

        // Send the success message
        await message.channel.send(`**Ownership has been moved from <@${oldOwnerId}> to <@${newOwnerId}> || <@${message.author.id}> ||**`);
        console.log(`[OWNERSHIP CHANGE]: Moved from ${oldOwnerId} to ${newOwnerId}`);
    } catch (err) {
        console.error("Error transferring ownership:", err);
        message.channel.send("**An error occurred while transferring ownership.**");
    }
};

module.exports.help = {
    name: "move_owner",
    aliases: ["move"]
};