const { removeLicenseById } = require('../tools/db'); // Reuse database functions
const logger = require('../tools/logger'); // Import the logger

module.exports.run = async (bot, message, args) => {
    const authorizedUserId = "355199972666376202"; // Replace with the authorized user ID

    // Check if the user is authorized
    if (message.author.id !== authorizedUserId) {
        message.delete();
        return message.channel.send("**You are not authorized to use this command.**");
    }

    // Check if all required arguments are provided
    if (args.length < 2) {
        message.delete();
        return message.channel.send("**Missing arguments. Usage: `!rid <OwnerID> <CustomID>`**");
    }

    const ownerId = args[0].trim(); // Sanitize input
    const customId = args[1].trim(); // Sanitize input

    // Delete the command message
    message.delete();

    try {
        // Remove the custom ID for the specified owner
        const result = await removeLicenseById(ownerId, customId);

        // Check if any rows were affected
        if (result.affectedRows === 0) {
            return message.channel.send(`**No license found for owner <@${ownerId}> with Script_ID \`${customId}\`.**`);
        }

        // Send the success message
        await message.channel.send(`**Script_ID \`${customId}\` has been removed for owner <@${ownerId}> || <@${message.author.id}> ||**`);
        console.log(`[LICENSE REMOVED] - [${new Date().toLocaleString()}]: Script_ID ${customId} removed for owner ${ownerId}`);
        // logger.info(`[LICENSE REMOVED]: License ${customId} removed for owner ${ownerId}`);
    } catch (err) {
        logger.error("Error removing license:", err);
        message.channel.send("**An error occurred while removing the license.**");
    }
};

module.exports.help = {
    name: "remove_id",
    aliases: ["rid"]
};