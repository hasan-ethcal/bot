const { checkLicenses } = require('../tools/db'); // Reuse database functions

module.exports.run = async (bot, message, args) => {
    const authorizedUserId = "355199972666376202"; // Replace with the authorized user ID

    // Check if the user is authorized
    if (message.author.id !== authorizedUserId) {
        message.delete();
        return message.channel.send("**You are not authorized to use this command.**");
    }

    // Check if all required arguments are provided
    if (args.length < 2) {
        message.delete();
        return message.channel.send("**Missing arguments. Usage: `!check <ip|owner> <value>`**");
    }

    const type = args[0].trim().toLowerCase(); // Sanitize and normalize input
    const value = args[1].trim(); // Sanitize input

    // Delete the command message
    message.delete();

    try {
        // Determine the query based on the type
        let logMessage, responseMessage;
        if (type === "ip") {
            logMessage = `[IP CHECK]: IP ${value}`;
            responseMessage = `**Licenses Linked to IP \`${value}\`:**\n`;
        } else if (type === "owner") {
            logMessage = `[OWNER CHECK]: Owner ${value}`;
            responseMessage = `**Licenses Owned by <@${value}>:**\n`;
        } else {
            return message.channel.send("**Invalid type. Use `ip` or `owner`.**");
        }

        // Query the database
        const result = await checkLicenses(type, value);

        // Check if any results were found
        if (result.length === 0) {
            return message.channel.send(`**No licenses found for ${type === "ip" ? `IP \`${value}\`` : `<@${value}>`}.**`);
        }

        // Build the response message
        result.forEach((element, index) => {
            if (type === "ip") {
                // Include Owner ID when checking by IP
                responseMessage += `${index + 1}. \`${element.ID}\` => IP: \`${element.IP}\`, Owner: <@${element.Owner}>\n`;
            } else {
                // Keep original format for owner checks
                responseMessage += `**${index + 1}.** \`${element.ID}\` => \`${element.IP}\`\n`;
            }
        });
        responseMessage += `**All Above ${type === "ip" ? `Linked to IP \`${value}\`` : `Owned by <@${value}>`}.**`;

        // Send the consolidated message
        await message.channel.send(responseMessage);

        // Log the action
        console.log(`${logMessage} returned ${result.length} results.`);
    } catch (err) {
        console.error("Error fetching data:", err);
        message.channel.send("**An error occurred while fetching the data.**");
    }
};

module.exports.help = {
    name: "check",
    aliases: ["ch"]
};