const { stopLicenses } = require('../tools/db'); // Reuse database functions

module.exports.run = async (bot, message, args) => {
    // Add both admin IDs to this array
    const authorizedUserId = ["355199972666376202", "695664615534755850"]; // Replace with the authorized Discord ID

    // Check if the user is authorized
    if (!authorizedUserId.includes(message.author.id)) {
        message.delete();
        return message.channel.send("**You are not authorized to use this command.**");
    }

    // Check if arguments are provided
    if (!args[0]) {
        message.delete();
        return message.channel.send("**Missing arguments. Usage: `!stop <OwnerID>`**");
    }

    const ownerId = args[0].trim(); // Sanitize input

    // Delete the command message
    message.delete();

    try {
        // Stop the licenses (update IP to '0')
        const result = await stopLicenses(ownerId);

        // Check if the owner exists in the database
        if (result.affectedRows === 0) {
            return message.channel.send(`**Owner <@${ownerId}> not found in the system.**`);
        }

        // Send the success message
        await message.channel.send(`**License FOR <@${ownerId}> HAS BEEN STOPPED || <@${message.author.id}> ||**`);
        console.log(`[LICENSE STOP]: FOR ${ownerId}`);
    } catch (err) {
        console.error("Error stopping licenses:", err);
        message.channel.send("**An error occurred while stopping the licenses.**");
    }
};

module.exports.help = {
    name: "stop_owner",
    aliases: ["stop"]
};