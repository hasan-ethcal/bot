const { removeOwner } = require('../tools/db'); // Reuse database functions

module.exports.run = async (bot, message, args) => {
    const authorizedUserId = "355199972666376202"; // Replace with the authorized user ID

    // Check if the user is authorized
    if (message.author.id !== authorizedUserId) {
        message.delete();
        return message.channel.send("**You are not authorized to use this command.**");
    }

    // Check if the required argument (Owner ID) is provided
    if (!args[0]) {
        message.delete();
        return message.channel.send("**Missing argument. Usage: `!removeowner <OwnerID>`**");
    }

    const ownerId = args[0].trim(); // Sanitize input

    // Delete the command message
    message.delete();

    try {
        // Remove all entries for the specified owner
        const result = await removeOwner(ownerId);

        // Check if any rows were affected
        if (result.affectedRows === 0) {
            return message.channel.send(`**No licenses found for owner <@${ownerId}>.**`);
        }

        // Send success message
        await message.channel.send(`**All licenses for owner <@${ownerId}> have been removed.**`);
        console.log(`[LICENSES REMOVED]: All licenses for owner ${ownerId} have been deleted.`);
    } catch (err) {
        console.error("Error removing licenses:", err);
        message.channel.send("**An error occurred while removing the licenses.**");
    }
};

module.exports.help = {
    name: "removeowner",
    aliases: ["remove"]
};