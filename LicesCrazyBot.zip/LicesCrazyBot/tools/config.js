module.exports = {
    botToken: "NzgyMjIwNDkwMTE0NTk2OTA0.GkPWPO.LCvkexBqV9baeyV4Y5XU6o6Xq8hQrl5gKKcmo4",
    prefix: "!",
    db: {
        host: "localhost",
        user: "super_roottt",
        password: "NBVutkcg012549^@!%$#!)@&@!",
        database: "crazysystem"
    }
};
