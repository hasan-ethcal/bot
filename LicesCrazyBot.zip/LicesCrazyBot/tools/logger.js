const winston = require('winston');

// Define log levels and colors
const logLevels = {
    levels: {
        error: 0,
        warn: 1,
        info: 2,
        debug: 3,
    },
    colors: {
        error: 'red',
        warn: 'yellow',
        info: 'green',
        debug: 'blue',
    },
};

// Add colors to winston
winston.addColors(logLevels.colors);

// Create a logger instance
const logger = winston.createLogger({
    levels: logLevels.levels,
    format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD || HH:mm:ss' }),
        winston.format.colorize(),
        winston.format.printf(({ timestamp, level, message }) => {
            return `[${timestamp}] [${level}]: ${message}`;
        })
    ),
    transports: [
        // Log to the console
        new winston.transports.Console({
            level: 'debug', // Log everything to the console
        }),
        // Log errors to a file
        new winston.transports.File({
            filename: 'logs/error.log',
            level: 'error', // Log only errors to this file
        }),
        // Log all messages to a file
        new winston.transports.File({
            filename: 'logs/combined.log',
            level: 'info', // Log info and above (info, warn, error)
        }),
    ],
});

module.exports = logger;