const mysql = require("mysql2");

// Database connection pool
const pool = mysql.createPool({
    host: "localhost", // Replace with your database host
    user: "super_roottt", // Replace with your database username
    password: "NBVutkcg012549^@!%$#!)@&@!", // Replace with your database password
    database: "crazysystem", // Replace with your database name
    connectionLimit: 99
});

// Handle database connection errors
pool.on('error', (err) => {
    console.error('Database pool error:', err);
});

// Function to fetch licenses
async function fetchLicenses(ownerId) {
    return new Promise((resolve, reject) => {
        pool.query("SELECT * FROM customers WHERE Owner = ?", [ownerId], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}

// Function to update licenses
async function updateLicenses(newIp, ownerId) {
    return new Promise((resolve, reject) => {
        pool.query("UPDATE customers SET IP = ? WHERE Owner = ?", [newIp, ownerId], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}

// Function to stop licenses (update IP to '127.0.0.1')
async function stopLicenses(ownerId) {
    return new Promise((resolve, reject) => {
        pool.query("UPDATE customers SET IP = '127.0.0.1' WHERE Owner = ?", [ownerId], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}

// Function to remove all licenses for an owner
async function removeOwner(ownerId) {
    return new Promise((resolve, reject) => {
        pool.query("DELETE FROM customers WHERE Owner = ?", [ownerId], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}

// Function to move ownership
async function moveOwner(oldOwnerId, newOwnerId) {
    return new Promise((resolve, reject) => {
        pool.query("UPDATE customers SET Owner = ? WHERE Owner = ?", [newOwnerId, oldOwnerId], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}


// Function to create a new license
async function createLicense(resourceId, serverIp, ownerId) {
    return new Promise((resolve, reject) => {
        pool.query("INSERT INTO customers (ID, IP, Owner) VALUES (?, ?, ?)", [resourceId, serverIp, ownerId], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}

// Function to check licenses by IP or Owner
async function checkLicenses(type, value) {
    return new Promise((resolve, reject) => {
        let query;
        if (type === "ip") {
            query = "SELECT * FROM customers WHERE IP = ?";
        } else if (type === "owner") {
            query = "SELECT * FROM customers WHERE Owner = ?";
        } else {
            return reject(new Error("Invalid type. Use 'ip' or 'owner'."));
        }

        pool.query(query, [value], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}

// Function to remove a license by ID for a specific owner
async function removeLicenseById(ownerId, customId) {
    return new Promise((resolve, reject) => {
        pool.query("DELETE FROM customers WHERE Owner = ? AND ID = ?", [ownerId, customId], (err, result) => {
            if (err) reject(err);
            else resolve(result);
        });
    });
}

// Function in index.js


module.exports = { fetchLicenses, updateLicenses, stopLicenses, removeOwner, moveOwner, createLicense, checkLicenses, removeLicenseById };