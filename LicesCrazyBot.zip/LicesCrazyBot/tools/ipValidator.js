// Validate IP address
function isValidIp(ip) {
    // Regex for IPv4
    const ipv4Regex = /^(?:\d{1,3}\.){3}\d{1,3}$/;
    // Regex for full IPv6
    const ipv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
    // Regex for shortened IPv6 (e.g., ::1 or 2001::1)
    const ipv6ShortRegex = /^(([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?::(([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?$/;

    return ipv4Regex.test(ip) || ipv6Regex.test(ip) || ipv6ShortRegex.test(ip);
}

module.exports = isValidIp;