const rateLimitMap = new Map();

// Simple in-memory rate limiter
function rateLimit(userId, limit = 99, windowMs = 15 * 60 * 1000) {
    const now = Date.now();
    const userRateLimit = rateLimitMap.get(userId) || { count: 0, lastRequest: 0 };

    if (now - userRateLimit.lastRequest > windowMs) {
        // Reset the count if the window has passed
        userRateLimit.count = 0;
        userRateLimit.lastRequest = now;
    }

    if (userRateLimit.count >= limit) {
        // User has exceeded the rate limit
        return false;
    }

    // Increment the count
    userRateLimit.count++;
    rateLimitMap.set(userId, userRateLimit);
    return true;
}

module.exports = rateLimit;