module.exports = {
    apps: [
      {
        name: "DiscordLicense",
        script: "index.js",
        watch: true,
        ignore_watch: ["node_modules", "logs"],
        log_file: "logs/discord.log",
        error_file: "logs/error.log"
      }
    ]
  };
  